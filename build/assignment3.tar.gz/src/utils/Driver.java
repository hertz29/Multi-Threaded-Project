package utils;

import REITSimulationObjects.Management;
import REITSimulationObjects.ReadXmlFile;

public class Driver {
	
	public static void main(String[] arg) throws InterruptedException{
		//String[] array = {"InitialData.xml", "AssetContentsRepairDetails.xml", "Assets.xml", "CustomersGroups.xml"};
		Management m1 = new Management();
		ReadXmlFile.initializeManagment(m1, arg);
		m1.startSimulation();
	}
}


